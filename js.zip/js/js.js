function hello(){
    let yourName = prompt("Please input your name");
    alert("Hello " + yourName)
}